package com.numbermagic.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private int secretNumber = 0;
    private boolean revealed = false;
    private HandDrawnNumberView numberView;
    private TextView statusView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildScreen();
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(28, 28, 28, 28);
        root.setBackgroundColor(0xFF17152B);

        TextView title = new TextView(this);
        title.setText("NUMBER MAGIC");
        title.setTextColor(Color.WHITE);
        title.setTextSize(28);
        title.setGravity(Gravity.CENTER);
        title.setLetterSpacing(0.08f);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        numberView = new HandDrawnNumberView();
        LinearLayout.LayoutParams numberParams = new LinearLayout.LayoutParams(-1, 0, 1f);
        numberParams.topMargin = 28;
        numberParams.bottomMargin = 18;
        root.addView(numberView, numberParams);

        statusView = new TextView(this);
        statusView.setText("गिनती छिपी है\nVolume Up (+): गिनती बढ़ाएँ\nVolume Down (−): नंबर दिखाएँ");
        statusView.setTextColor(0xFFE7E4F5);
        statusView.setTextSize(18);
        statusView.setGravity(Gravity.CENTER);
        statusView.setLineSpacing(8, 1f);
        root.addView(statusView, new LinearLayout.LayoutParams(-1, -2));

        TextView note = new TextView(this);
        note.setText("ट्रिक चलाने के लिए ऐप खुली रखें");
        note.setTextColor(0xFFAAA6C4);
        note.setTextSize(14);
        note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams noteParams = new LinearLayout.LayoutParams(-1, -2);
        noteParams.topMargin = 34;
        root.addView(note, noteParams);
        setContentView(root);
        numberView.showHidden();
    }

    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN && event.getRepeatCount() == 0) {
            if (event.getKeyCode() == KeyEvent.KEYCODE_VOLUME_UP) {
                secretNumber = (secretNumber % 9) + 1;
                revealed = false;
                numberView.showHidden();
                statusView.setText("गिनती छिपी है\nVolume Up: गिनती बढ़ाएँ\nVolume Down: नंबर दिखाएँ");
                return true;
            }
            if (event.getKeyCode() == KeyEvent.KEYCODE_VOLUME_DOWN) {
                if (secretNumber == 0) secretNumber = 1;
                revealed = true;
                numberView.showNumber(secretNumber);
                statusView.setText("आपका नंबर है!");
                return true;
            }
        }
        if (event.getKeyCode() == KeyEvent.KEYCODE_VOLUME_UP || event.getKeyCode() == KeyEvent.KEYCODE_VOLUME_DOWN) return true;
        return super.dispatchKeyEvent(event);
    }

    // Paints a deliberately imperfect, finger-drawn-looking numeral rather than a font glyph.
    private class HandDrawnNumberView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private int digit = 0;
        private boolean hidden = true;
        HandDrawnNumberView() { super(MainActivity.this); paint.setColor(0xFFFFD166); paint.setStyle(Paint.Style.STROKE); paint.setStrokeCap(Paint.Cap.ROUND); paint.setStrokeJoin(Paint.Join.ROUND); }
        void showHidden() { hidden = true; invalidate(); }
        void showNumber(int n) { digit = n; hidden = false; invalidate(); }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if (hidden) {
                paint.setStyle(Paint.Style.FILL); paint.setTextAlign(Paint.Align.CENTER); paint.setTextSize(92); paint.setStrokeWidth(1);
                canvas.drawText("?", getWidth()/2f, getHeight()/2f + 30, paint);
                paint.setStyle(Paint.Style.STROKE); return;
            }
            canvas.save();
            float scale = Math.min(getWidth(), getHeight()) / 190f;
            canvas.translate((getWidth()-150*scale)/2f, (getHeight()-190*scale)/2f);
            canvas.scale(scale, scale);
            paint.setStrokeWidth(9f);
            Path p = new Path();
            switch (digit) {
                case 1: p.moveTo(48,45); p.lineTo(77,25); p.lineTo(76,158); p.moveTo(45,158); p.lineTo(112,156); break;
                case 2: p.moveTo(34,48); p.quadTo(43,15,82,26); p.quadTo(125,34,108,69); p.lineTo(38,143); p.quadTo(30,154,48,155); p.lineTo(119,151); break;
                case 3: p.moveTo(37,34); p.quadTo(88,8,110,38); p.quadTo(124,62,77,82); p.quadTo(127,83,119,119); p.quadTo(112,163,38,146); break;
                case 4: p.moveTo(94,158); p.lineTo(95,24); p.lineTo(31,108); p.lineTo(126,105); break;
                case 5: p.moveTo(112,27); p.lineTo(48,29); p.lineTo(43,75); p.quadTo(98,60,115,96); p.quadTo(133,142,78,154); p.quadTo(49,158,34,142); break;
                case 6: p.moveTo(105,28); p.quadTo(49,38,37,94); p.quadTo(21,151,74,155); p.quadTo(122,157,116,116); p.quadTo(109,79,51,96); break;
                case 7: p.moveTo(31,31); p.lineTo(121,28); p.lineTo(61,157); break;
                case 8: p.moveTo(76,82); p.quadTo(31,68,44,39); p.quadTo(62,12,92,31); p.quadTo(119,51,80,81); p.quadTo(24,99,40,132); p.quadTo(62,169,104,144); p.quadTo(133,119,76,82); break;
                case 9: p.moveTo(109,81); p.quadTo(64,103,41,72); p.quadTo(19,34,61,24); p.quadTo(112,11,116,57); p.lineTo(107,119); p.quadTo(99,150,63,157); break;
            }
            canvas.drawPath(p, paint);
            canvas.restore();
        }
    }
}
